                <hr id="linha" /><br><br>
                <div class="plataforma">
                    <h2>Plataforma</h2>
                    <ul>
                        <a href="<?php print $plataformaLoc  ?>?plataforma=PC"><li>PC</li></a>
                        <a href="<?php print $plataformaLoc  ?>?plataforma=PS4"><li>PS4</li></a>
                        <a href="<?php print $plataformaLoc  ?>?plataforma=PS3"><li>PS3</li></a>
                        <a href="<?php print $plataformaLoc  ?>?plataforma=XBOX ONE"><li>XBOX ONE</li></a>
                        <a href="<?php print $plataformaLoc  ?>?plataforma=XBOX 360"><li>XBOX 360</li></a>
                        <a href="<?php print $plataformaLoc  ?>?plataforma=PS Vita"><li>PS Vita</li></a>
                        <a href="<?php print $plataformaLoc  ?>?plataforma=Wii U"><li>Wii U</li></a>
                        <a href="<?php print $plataformaLoc  ?>?plataforma=Wii"><li>Wii</li></a>
                        <a href="<?php print $plataformaLoc  ?>?plataforma=3DS"><li>3DS</li></a>
                        <a href="<?php print $plataformaLoc  ?>?plataforma=Nitendo Switch"><li>Nitendo Switch</li></a>
                    </ul>
                </div>
                </div>

                <div id="footer">
                <footer>
                    <ul id="contato">
                        <li class="footerTitle">CONTATE-NOS</li>
                        <li><a href="<?php print $pagcontato ?>" class="itemFooter">FALE CONOSCO</a></li>
                        <li><a href="<?php print $pagparcerias ?>" class="itemFooter">PARCERIAS</a></li>
                    </ul>

                    <ul id="links">
                        <li class="footerTitle">LINKS</li>
                        <li><a href="<?php print $pagindex ?>" class="itemFooter">NOTÍCIAS</a></li>
                        <li><a href="<?php print $pagjogos ?>" class="itemFooter">JOGOS</a></li>
                        <li><a href="<?php print $pagcomparajogos ?>" class="itemFooter">COMPARAR JOGOS</a></li>
                        <li><a href="<?php print $pagsobrenos ?>" class="itemFooter">SOBRE NÓS</a></li>
                        <li><a href="<?php print $pagesports ?>" class="itemFooter">E-SPORTS</a></li>
                    </ul>

                    <div id="redesociais">
                        <h4 class="footerTitle">REDES SOCIAIS</h4>
                        <a href="https://www.facebook.com/" target="_blank"><img src="<?php print $icoFacebook ?>" alt="Facebook" title="Facebook" /></a>
                        <a href="http://www.twitter.com.br/" target="_blank"><img src="<?php print $icoTwitter ?>" alt="Twitter" title="Twitter" /></a>
                        <a href="https://www.twitch.tv/" target="_blank"><img src="<?php print $icoTwitch ?>" alt="Twitch" title="Twitch" /></a>
                        <a href="https://www.youtube.com/" target="_blank"><img src="<?php print $icoYoutube ?>" alt="YouTube" title="YouTube" /></a>
                    </div>
                </footer>
            </div>
        </div>
    </body>
</html>
